//
//  TTRFlowStatistics.h
//  Article
//
//  Created by wangdi on 2017/7/3.
//
//

#import "TTRDynamicPlugin.h"

@interface TTRFlowStatistics : TTRDynamicPlugin

//TTRFlowStatistics.flowStatistics
TTR_EXPORT_HANDLER(flowStatistics)

@end
