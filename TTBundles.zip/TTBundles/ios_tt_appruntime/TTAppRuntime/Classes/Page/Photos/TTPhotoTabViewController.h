//
//  TTPhotoTabViewController.h
//  Article
//
//  Created by 刘廷勇 on 15/11/3.
//
//

#import <UIKit/UIKit.h>

@class TTCollectionPageViewController;
@interface TTPhotoTabViewController : UIViewController

@property (nonatomic, readonly) TTCollectionPageViewController *pageViewController;
@end
