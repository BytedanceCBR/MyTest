//
//  TTDetailNatantVideoInfoViewModel.m
//  Article
//
//  Created by Ray on 16/4/15.
//
//

#import "TTDetailNatantVideoInfoViewModel.h"

@implementation TTDetailNatantVideoInfoViewModel

@end
