//
//  TTDetailNatantRiskWarningView.h
//  Article
//
//  Created by Ray on 16/4/6.
//
//

#import "TTDetailNatantViewBase.h"

@interface TTDetailNatantRiskWarningView : TTDetailNatantViewBase

@end
