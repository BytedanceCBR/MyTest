//
//  TTVideoDetailCommon.h
//  Article
//
//  Created by panxiang on 16/8/11.
//
//

#import <Foundation/Foundation.h>

#define kRelatedClickedNotification @"kRelatedClickedNotification"

