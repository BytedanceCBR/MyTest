//
//  TTDetailNatantTagsView.h
//  Article
//
//  Created by Ray on 16/5/4.
//
//

#import "TTDetailNatantViewBase.h"

@interface TTDetailNatantTagsView : TTDetailNatantViewBase

@end
