//
//  TTDetailNatantVideoInfoViewModel.h
//  Article
//
//  Created by Ray on 16/4/15.
//
//

#import <Foundation/Foundation.h>

@interface TTDetailNatantVideoInfoViewModel : NSObject

@end
