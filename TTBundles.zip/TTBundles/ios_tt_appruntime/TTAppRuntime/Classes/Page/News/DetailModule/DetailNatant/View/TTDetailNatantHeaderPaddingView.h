//
//  TTDetailNatantHeaderPaddingView.h
//  Article
//
//  Created by Ray on 16/4/8.
//
//

#import "TTDetailNatantViewBase.h"

@interface TTDetailNatantHeaderPaddingView : TTDetailNatantViewBase

+ (float)viewHeight;

@end
