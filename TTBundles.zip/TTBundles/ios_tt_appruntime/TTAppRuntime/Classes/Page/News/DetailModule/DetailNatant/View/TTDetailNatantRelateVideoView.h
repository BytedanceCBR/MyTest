//
//  TTDetailNatantRelateVideoView.h
//  Article
//
//  Created by Ray on 16/4/11.
//
//

#import "TTDetailNatantViewBase.h"
#import "TTImageInfosModel.h"

@interface TTDetailNatantRelateVideoView : TTDetailNatantViewBase

+ (float)heightForTTImageInfosModel:(nullable TTImageInfosModel *)model viewWidth:(float)viewWidth;

@end
