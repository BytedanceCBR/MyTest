//
//  NewsBaseDelegate+UI.h
//  Article
//
//  Created by fengyadong on 17/1/17.
//
//
#if 0
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (UI)

- (void)didFinishUILaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

- (void)didFinishWebviewLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;
    
@end
#endif
