//
//  NewsBaseDelegate+SDKs.h
//  Article
//
//  Created by fengyadong on 17/1/16.
//
//
#if 0
#import <Foundation/Foundation.h>
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (SDKs)

- (void)didFinishSDKsLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

@end
#endif
