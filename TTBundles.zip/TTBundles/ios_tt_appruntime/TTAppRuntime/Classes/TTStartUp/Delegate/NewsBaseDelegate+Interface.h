//
//  NewsBaseDelegate+Interface.h
//  Article
//
//  Created by fengyadong on 17/1/18.
//
//
#if 0
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (Interface)

- (void)didFinishInterfaceLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

@end
#endif
