//
//  NewsBaseDelegate+Notification.h
//  Article
//
//  Created by fengyadong on 17/1/18.
//
//
#if 0
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (Notification)

- (void)didFinishNotificationLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

@end
#endif
