//
//  NewsBaseDelegate+Serial.h
//  Article
//
//  Created by fengyadong on 17/1/17.
//
//
#if 0
#import <Foundation/Foundation.h>
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (Serial)

- (void)didFinishSerialLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

@end
#endif
