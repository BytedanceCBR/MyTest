//
//  NewsBaseDelegate+Service.h
//  Article
//
//  Created by fengyadong on 17/1/17.
//
//
#if 0
#import <Foundation/Foundation.h>
#import "NewsBaseDelegate.h"

@interface NewsBaseDelegate (Service)

- (void)didFinishServiceLaunchingForApplication:(UIApplication *)application WithOptions:(NSDictionary *)options;

@end
#endif
