//
//  TTQQSDKRegister.h
//  Article
//
//  Created by 王霖 on 2017/7/26.
//
//

#import "TTStartupTask.h"

@interface TTQQSDKRegister : TTStartupTask

@end
