//
//  TTWeixinSDKRegister.h
//  Article
//
//  Created by fengyadong on 17/1/16.
//
//

#import "TTStartupTask.h"

@interface TTWeixinSDKRegister : TTStartupTask

@end
