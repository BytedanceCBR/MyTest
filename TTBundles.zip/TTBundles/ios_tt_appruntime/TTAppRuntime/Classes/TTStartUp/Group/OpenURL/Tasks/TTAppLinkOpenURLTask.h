//
//  TTAppLinkOpenURLTask.h
//  Article
//
//  Created by fengyadong on 17/1/24.
//
//

#import "TTStartupTask.h"

@interface TTAppLinkOpenURLTask : TTStartupTask<UIApplicationDelegate>

@end
