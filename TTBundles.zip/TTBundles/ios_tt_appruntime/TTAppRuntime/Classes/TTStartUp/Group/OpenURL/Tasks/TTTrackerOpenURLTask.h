//
//  TTTrackerOpenURLTask.h
//  Article
//
//  Created by fengyadong on 2017/8/4.
//
//

#import "TTStartupTask.h"

@interface TTTrackerOpenURLTask : TTStartupTask<UIApplicationDelegate>

@end
