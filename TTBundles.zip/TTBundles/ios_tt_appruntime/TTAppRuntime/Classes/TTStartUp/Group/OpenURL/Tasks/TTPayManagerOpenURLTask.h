//
//  TTPayManagerOpenURLTask.h
//  Article
//
//  Created by fengyadong on 17/1/24.
//
//

#import "TTStartupTask.h"

@interface TTPayManagerOpenURLTask : TTStartupTask<UIApplicationDelegate>

@end
