//
//  TTOpenURLFeedBackLogTask.h
//  Article
//
//  Created by tyh on 2017/9/11.
//
//

#import "TTStartupTask.h"

@interface TTOpenURLFeedBackLogTask : TTStartupTask<UIApplicationDelegate>

@end
