//
//  TTLaunchTimerTask.h
//  Article
//
//  Created by 王双华 on 2017/7/11.
//
//

#import "TTStartupTask.h"

@interface TTLaunchTimerTask : TTStartupTask

@end
