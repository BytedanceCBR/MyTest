//
//  TTCookieStartupTask.m
//  Article
//
//  Created by fengyadong on 17/1/22.
//
//

#import "TTCookieStartupTask.h"
#import "SSCookieManager.h"
#import "ExploreExtenstionDataHelper.h"
#import <TTBaseLib/TTDeviceHelper.h>
#import <TTBaseLib/TTBaseMacro.h>
#import "TTLaunchDefine.h"

DEC_TASK("TTCookieStartupTask",FHTaskTypeService,TASK_PRIORITY_HIGH+8);
@implementation TTCookieStartupTask

- (NSString *)taskIdentifier {
    return @"TimeInterval";
}

- (BOOL)isResident {
    return YES;
}

#pragma mark - UIApplicationDelegate Method
- (void)applicationDidEnterBackground:(UIApplication *)application {
    //共享cookie 给extenstion
    if (!isEmptyString([SSCookieManager sessionIDFromCookie])) {
        [ExploreExtenstionDataHelper saveSharedSessionID:[SSCookieManager sessionIDFromCookie]];
    }
    //共享openUDID给extension
    NSString *openUDID = [TTDeviceHelper openUDID];
    if (!isEmptyString(openUDID)) {
        [ExploreExtenstionDataHelper saveSharedOpenUDID:openUDID];
    }
}

@end
