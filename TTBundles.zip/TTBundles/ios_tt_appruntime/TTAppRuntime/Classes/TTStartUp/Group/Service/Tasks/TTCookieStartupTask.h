//
//  TTCookieStartupTask.h
//  Article
//
//  Created by fengyadong on 17/1/22.
//
//

#import "TTStartupTask.h"

@interface TTCookieStartupTask : TTStartupTask<UIApplicationDelegate>

@end
