//
//  TTCommonURLSettingTask.h
//  Article
//
//  Created by xuzichao on 2017/6/8.
//
//

#import "TTStartupTask.h"

@interface TTCommonURLSettingTask : TTStartupTask <UIApplicationDelegate>

@end
