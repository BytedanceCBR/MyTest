//
//  TTiOS10NotificationCheckTask.h
//  Article
//
//  Created by chenren on 04/05/2017.
//
//

#import "TTStartupTask.h"

@interface TTiOS10NotificationCheckTask : TTStartupTask<UIApplicationDelegate>

@end
