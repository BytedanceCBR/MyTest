//
//  TTIESPlayerTask.h
//  Article
//
//  Created by 邱鑫玥 on 2018/1/7.
//

#import "TTStartupTask.h"

@interface TTIESPlayerTask : TTStartupTask

@end
