//
//  TTUniversalLinksTask.h
//  Article
//
//  Created by fengyadong on 17/1/22.
//
//

#import "TTStartupTask.h"

@interface TTUniversalLinksTask : TTStartupTask<UIApplicationDelegate>

@end
