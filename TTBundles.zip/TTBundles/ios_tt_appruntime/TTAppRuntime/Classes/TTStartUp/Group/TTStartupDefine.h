//
//  TTStartupDefine.h
//  Article
//
//  Created by fengyadong on 17/2/6.
//
//

#ifndef TTStartupDefine_h
#define TTStartupDefine_h

extern NSString *const TTStartupProtectPrefix;

#endif /* TTStartupDefine_h */
