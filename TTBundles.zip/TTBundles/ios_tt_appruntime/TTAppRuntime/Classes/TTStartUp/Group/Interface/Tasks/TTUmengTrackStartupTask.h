//
//  TTUmengTrackStartupTask.h
//  Article
//
//  Created by fengyadong on 17/1/18.
//
//

#import "TTStartupTask.h"

@interface TTUmengTrackStartupTask : TTStartupTask

@end
