//
//  TTGetDomainTask.h
//  Article
//
//  Created by fengyadong on 17/1/20.
//
//

#import "TTStartupTask.h"

@interface TTGetDomainTask : TTStartupTask<UIApplicationDelegate>

@end
