//
//  TTMessageNotificationStartupTask.m
//  Article
//
//  Created by 邱鑫玥 on 2017/5/3.
//
//

#import "TTMessageNotificationStartupTask.h"
#import "FHMessageNotificationManager.h"
#import "ArticleMessageManager.h"
#import "TTLaunchDefine.h"

DEC_TASK("TTMessageNotificationStartupTask",FHTaskTypeInterface,TASK_PRIORITY_HIGH+11);

@implementation TTMessageNotificationStartupTask

- (NSString *)taskIdentifier {
    return @"MessageNotification";
}

#pragma mark - UIApplicationDelegate Method
- (void)startWithApplication:(UIApplication *)application options:(NSDictionary *)launchOptions
{
    //新消息通知定时轮询未读消息
    dispatch_async(dispatch_get_main_queue(), ^{
        [[FHMessageNotificationManager sharedManager] startPeriodicalFetchUnreadMessageNumberWithChannel:nil];
        [ArticleMessageManager startPeriodicalGetFollowNumber];
    });
}

@end
