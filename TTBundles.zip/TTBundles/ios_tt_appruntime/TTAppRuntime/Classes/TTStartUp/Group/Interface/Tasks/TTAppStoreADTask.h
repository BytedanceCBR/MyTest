//
//  TTAppStoreADTask.h
//  Article
//
//  Created by fengyadong on 17/1/19.
//
//

#import "TTStartupTask.h"

@interface TTAppStoreADTask : TTStartupTask

@end
