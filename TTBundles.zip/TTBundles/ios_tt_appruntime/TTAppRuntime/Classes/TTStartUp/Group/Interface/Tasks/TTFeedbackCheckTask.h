//
//  TTFeedbackCheckTask.h
//  Article
//
//  Created by fengyadong on 17/1/20.
//
//

#import "TTStartupTask.h"

@interface TTFeedbackCheckTask : TTStartupTask<UIApplicationDelegate>

@end
