//
//  TTProfileEntryStartupTask.h
//  Article
//
//  Created by lizhuoli on 2017/6/18.
//
//

#import "TTStartupTask.h"

/**
 * 我的页面入口刷新task
 * 包括了我的页面的Entry，我的关注刷新的通知注册
 */
@interface TTProfileEntryStartupTask : TTStartupTask

@end
