//
//  TTPermissionSettingsReportTask.h
//  Article
//
//  Created by chenren on 05/07/2017.
//
//

#import "TTStartupTask.h"

@interface TTPermissionSettingsReportTask : TTStartupTask

@end
