//
//  TTSetUseBDWebImageTask.h
//  Article
//
//  Created by yxj on 07/02/2018.
//

#import "TTStartupTask.h"

@interface TTSetUseBDWebImageTask : TTStartupTask

@end
