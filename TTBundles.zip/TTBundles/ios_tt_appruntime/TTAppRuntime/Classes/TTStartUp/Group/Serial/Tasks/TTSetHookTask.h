//
//  TTSetHookTask.h
//  Article
//
//  Created by Chen Hong on 2017/6/29.
//
//

#import "TTStartupTask.h"

@interface TTSetHookTask : TTStartupTask

@end
