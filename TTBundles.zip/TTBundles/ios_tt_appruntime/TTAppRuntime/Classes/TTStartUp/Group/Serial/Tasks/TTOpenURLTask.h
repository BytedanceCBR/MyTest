//
//  TTOpenURLTask.h
//  Article
//
//  Created by 春晖 on 2019/3/4.
//

#import "TTStartupTask.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTOpenURLTask : TTStartupTask<UIApplicationDelegate>

@end

NS_ASSUME_NONNULL_END
