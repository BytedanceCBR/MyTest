//
//  TTClearCacheTask.h
//  Article
//
//  Created by fengyadong on 17/1/18.
//
//

#import "TTStartupTask.h"

@interface TTClearCacheTask : TTStartupTask

@end
