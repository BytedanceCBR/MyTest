//
//  FHIMStartupTask.h
//  Article
//
//  Created by leo on 2019/2/17.
//

#import <Foundation/Foundation.h>
#import "TTStartupTask.h"

NS_ASSUME_NONNULL_BEGIN

@interface FHIMStartupTask : TTStartupTask

@end

NS_ASSUME_NONNULL_END
