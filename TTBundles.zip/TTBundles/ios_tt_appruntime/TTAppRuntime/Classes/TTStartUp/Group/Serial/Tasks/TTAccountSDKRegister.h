//
//  TTAccountSDKRegister.h
//  wenda
//
//  Created by liuzuopeng on 5/16/17.
//  Copyright © 2017 Bytedance Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TTStartupTask.h"



@interface TTAccountSDKRegister : TTStartupTask

@end
