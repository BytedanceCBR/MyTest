//
//  TTFabricSDKRegister.h
//  Article
//
//  Created by fengyadong on 17/1/16.
//
//

#import "TTStartupTask.h"
#import <Crashlytics/Crashlytics.h>

@interface TTFabricSDKRegister : TTStartupTask<CrashlyticsDelegate,UIApplicationDelegate>

@end
