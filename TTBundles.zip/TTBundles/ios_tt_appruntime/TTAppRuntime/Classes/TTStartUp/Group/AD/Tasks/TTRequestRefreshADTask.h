//
//  TTRequestRefreshADTask.h
//  Article
//
//  Created by ranny_90 on 2017/3/21.
//
//

#import "TTStartupTask.h"

@interface TTRequestRefreshADTask : TTStartupTask<UIApplicationDelegate>

@end
