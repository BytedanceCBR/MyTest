//
//  TTDefaultBinaryResponseSerializer.h
//  Article
//
//  Created by Huaqing Luo on 10/9/15.
//
//

#import "TTHTTPResponseSerializerProtocol.h"

@interface TTDefaultBinaryResponseSerializer : NSObject<TTBinaryResponseSerializerProtocol>

@end
