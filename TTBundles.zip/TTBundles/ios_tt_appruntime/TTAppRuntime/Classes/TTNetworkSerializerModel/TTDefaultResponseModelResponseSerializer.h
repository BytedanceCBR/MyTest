//
//  TTDefaultResponseModelResponseSerializer.h
//  Article
//
//  Created by Huaqing Luo on 11/9/15.
//
//

#import "TTDefaultJSONResponseSerializer.h"

@interface TTDefaultResponseModelResponseSerializer : TTDefaultJSONResponseSerializer<TTResponseModelResponseSerializerProtocol>

@end
