//
//  BDTDefaultHTTPRequestSerializer.h
//  Article
//
//  Created by zuopengliu on 27/2/2018.
//

#import <Foundation/Foundation.h>
#import <TTNetworkManager/TTHTTPRequestSerializerBase.h>



@interface BDTDefaultHTTPRequestSerializer : TTHTTPRequestSerializerBase

@end
