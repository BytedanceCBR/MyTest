//
//  TTFavoriteSearchViewController.h
//  Article
//
//  Created by lizhuoli on 16/12/29.
//
//

#import "ExploreSearchViewController.h"

@interface TTFavoriteSearchViewController : ExploreSearchViewController

@end
