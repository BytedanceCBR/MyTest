//
//  TTFavoriteHistoryViewController.h
//  Article
//
//  Created by fengyadong on 16/11/22.
//
//

#import "SSViewControllerBase.h"

@interface TTFavoriteHistoryViewController : SSViewControllerBase

- (instancetype)initWithRouteParamObj:(TTRouteParamObj *)paramObj;

@end
