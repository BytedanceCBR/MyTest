//
//  TTFavoriteViewController.h
//  Article
//
//  Created by fengyadong on 16/11/17.
//
//

#import "SSViewControllerBase.h"
#import "TTFeedFavoriteHistoryHeader.h"

#define kHasBottomTipFavlistClosedUserDefaultKey @"kHasBottomTipFavlistClosedUserDefaultKey"

@interface TTFavoriteViewController : SSViewControllerBase <TTFeedFavoriteHistoryProtocol>

@end
