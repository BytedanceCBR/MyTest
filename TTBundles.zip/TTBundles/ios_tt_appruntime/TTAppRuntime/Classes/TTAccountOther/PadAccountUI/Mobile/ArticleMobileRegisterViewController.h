//
//  ArticleMobileRegisterViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-2.
//
//

#import "ArticleMobileViewController.h"



/// 注册
@interface ArticleMobileRegisterViewController : ArticleMobileViewController

@end
