//
//  ArticleMobileSettingViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-11.
//
//

#import "ArticleMobileViewController.h"



@interface ArticleMobileSettingViewController : ArticleMobileViewController

@end
