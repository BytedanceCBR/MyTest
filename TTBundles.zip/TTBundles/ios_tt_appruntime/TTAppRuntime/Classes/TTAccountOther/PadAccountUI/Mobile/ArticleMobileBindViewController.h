//
//  ArticleMobileBindViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-10.
//
//

#import "ArticleMobileViewController.h"

@interface ArticleMobileBindViewController : ArticleMobileViewController

@end
