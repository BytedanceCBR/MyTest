//
//  ArticleMobileChangeViewController.h
//  Article
//
//  Created by Huaqing Luo on 28/7/15.
//
//

#import "ArticleMobileViewController.h"



@interface ArticleMobileChangeViewController : ArticleMobileViewController

@end
