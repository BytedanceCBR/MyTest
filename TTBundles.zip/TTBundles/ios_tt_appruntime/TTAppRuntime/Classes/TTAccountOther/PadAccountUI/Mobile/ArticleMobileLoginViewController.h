//
//  ArticleMobileLoginViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-4.
//
//

#import <SSViewControllerBase.h>
#import "ArticleMobileViewController.h"



@interface ArticleMobileLoginViewController : ArticleMobileViewController

@property (nonatomic, strong, readonly) SSThemedTextField *mobileField;

@end
