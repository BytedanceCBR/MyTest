//
//  ArticleMobileRetrieveViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-9.
//
//

#import "ArticleMobileViewController.h"



/// 找回密码
@interface ArticleMobileRetrieveViewController : ArticleMobileViewController

@end
