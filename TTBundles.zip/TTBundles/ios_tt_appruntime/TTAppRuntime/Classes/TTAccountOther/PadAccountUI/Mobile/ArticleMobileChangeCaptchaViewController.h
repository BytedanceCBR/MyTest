//
//  ArticleMobileCaptchaViewController.h
//  Article
//
//  Created by Huaqing Luo on 30/7/15.
//
//

#import "ArticleMobileViewController.h"



@interface ArticleMobileChangeCaptchaViewController : ArticleMobileViewController

@end
