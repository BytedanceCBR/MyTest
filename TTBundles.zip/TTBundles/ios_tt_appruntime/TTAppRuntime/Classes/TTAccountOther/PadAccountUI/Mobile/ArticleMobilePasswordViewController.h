//
//  ArticleMobilePasswordViewController.h
//  Article
//
//  Created by SunJiangting on 14-7-15.
//
//

#import "ArticleMobileViewController.h"



@interface ArticleMobilePasswordViewController : ArticleMobileViewController

@end
