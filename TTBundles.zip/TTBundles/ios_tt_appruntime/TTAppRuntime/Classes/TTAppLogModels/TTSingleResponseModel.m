//
//  TTSingleResponseModel.m
//  Article
//
//  Created by chenjiesheng on 16/12/15.
//
//

#import "TTSingleResponseModel.h"

@implementation TTSingleResponseModel

@end
