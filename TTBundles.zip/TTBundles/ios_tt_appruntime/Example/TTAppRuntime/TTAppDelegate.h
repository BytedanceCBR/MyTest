//
//  TTAppDelegate.h
//  TTAppRuntime
//
//  Created by guchunhui on 04/16/2019.
//  Copyright (c) 2019 guchunhui. All rights reserved.
//

@import UIKit;

@interface TTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
