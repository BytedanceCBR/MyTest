//
//  AKPhotoCarouselCellModel.h
//  Article
//
//  Created by chenjiesheng on 2018/3/6.
//

#import <JSONModel.h>

@interface AKPhotoCarouselCellModel : JSONModel

@property (nonatomic, copy)NSString *imageURL;
@property (nonatomic, copy)NSString *openURL;

@end
