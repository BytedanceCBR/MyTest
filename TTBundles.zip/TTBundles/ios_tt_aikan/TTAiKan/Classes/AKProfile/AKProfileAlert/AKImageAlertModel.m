//
//  AKImageAlertModel.m
//  Article
//
//  Created by chenjiesheng on 2018/3/8.
//

#import "AKImageAlertModel.h"

@implementation AKImageAlertModel


- (NSString *)interfaceTipViewIdentifier
{
    return @"AKImageAlertView";
}
@end
