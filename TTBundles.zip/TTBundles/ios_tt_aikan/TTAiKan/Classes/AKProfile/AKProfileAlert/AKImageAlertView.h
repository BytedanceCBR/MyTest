//
//  AKImageAlertView.h
//  Article
//
//  Created by chenjiesheng on 2018/3/8.
//

#import "TTInterfaceTipBaseView.h"

@interface AKImageAlertView : TTInterfaceTipBaseView

@end
