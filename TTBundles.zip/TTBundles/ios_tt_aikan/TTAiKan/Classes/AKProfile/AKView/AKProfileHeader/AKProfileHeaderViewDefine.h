//
//  AKProfileHeaderViewDefine.h
//  Article
//
//  Created by chenjiesheng on 2018/3/6.
//

#ifndef AKProfileHeaderViewDefine_h
#define AKProfileHeaderViewDefine_h

#define kHPaddingContentView                            [TTDeviceUIUtils tt_newPadding:15]
#define kHeightProfileHeaderViewInfoView                [TTDeviceUIUtils tt_newPadding:100]
#define kHeightProfileHeaderViewBeneficialView          [TTDeviceUIUtils tt_newPadding:80]

#endif /* AKProfileHeaderViewDefine_h */
