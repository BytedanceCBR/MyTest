//
//  AKHTTPPostRequestSerializer.h
//  News
//
//  Created by 冯靖君 on 2018/3/16.
//

#import "TTDefaultHTTPRequestSerializer.h"

@interface AKHTTPPostRequestSerializer : TTDefaultHTTPRequestSerializer

@end
