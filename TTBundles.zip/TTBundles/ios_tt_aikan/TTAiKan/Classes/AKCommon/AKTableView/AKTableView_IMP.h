//
//  AKTableView_IMP.h
//  Article
//
//  Created by 冯靖君 on 2018/4/16.
//

#import <Foundation/Foundation.h>
#import "UITableView+Block.h"

@interface AKTableView_IMP : NSObject <UITableViewDataSource, UITableViewDelegate>

@end
