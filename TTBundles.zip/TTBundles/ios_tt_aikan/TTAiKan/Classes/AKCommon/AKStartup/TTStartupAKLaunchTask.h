//
//  TTStartupAKLaunchTask.h
//  Article
//
//  Created by 冯靖君 on 2018/3/25.
//

#import "TTStartupTask.h"

@interface TTStartupAKLaunchTask : TTStartupTask

@end
