//
//  AKAwardCoinTipModel.m
//  Article
//
//  Created by chenjiesheng on 2018/3/12.
//

#import "AKAwardCoinTipModel.h"

@implementation AKAwardCoinTipModel

- (NSString *)interfaceTipViewIdentifier
{
    return @"AKAwardCoinTipView";
}

@end
