//
//  AKAwardCoinTipView.h
//  Article
//
//  Created by chenjiesheng on 2018/3/12.
//

#import "TTInterfaceTipBaseView.h"

@interface AKAwardCoinTipView : TTInterfaceTipBaseView

@end
