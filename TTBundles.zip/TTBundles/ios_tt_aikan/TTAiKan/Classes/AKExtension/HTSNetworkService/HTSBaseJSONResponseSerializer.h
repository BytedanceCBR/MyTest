//
//  HTSNetworkResponseSerializer.h
//  LiveStreaming
//
//  Created by 权泉 on 2017/5/11.
//  Copyright © 2017年 Bytedance. All rights reserved.
//

#import <TTNetworkManager/TTNetworkManager.h>
#import <TTNetworkManager/TTHTTPResponseSerializerBase.h>

@interface HTSBaseJSONResponseSerializer : TTHTTPJSONResponseSerializerBase

@end
