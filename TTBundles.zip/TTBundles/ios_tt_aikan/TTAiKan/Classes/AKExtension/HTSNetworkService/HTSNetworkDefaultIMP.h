//
//  HTSNetworkDefaultIMP.h
//  Pods
//
//  Created by 权泉 on 2017/5/11.
//
//

#import <Foundation/Foundation.h>
#import "HTSNetworkProtocol.h"

@interface HTSNetworkDefaultIMP : NSObject <HTSNetworkProtocol>


@end
