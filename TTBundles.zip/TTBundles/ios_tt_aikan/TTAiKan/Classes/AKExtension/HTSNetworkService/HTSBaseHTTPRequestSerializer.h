//
//  HTSBaseHTTPRequestSerializer.h
//  Pods
//
//  Created by 权泉 on 2017/5/11.
//
//

#import <TTNetworkManager/TTNetworkManager.h>
#import <TTNetworkManager/TTHTTPRequestSerializerBase.h>

@interface HTSBaseHTTPRequestSerializer : TTHTTPRequestSerializerBase

@end
