//
//  main.m
//  TTAiKan
//
//  Created by guchunhui on 04/16/2019.
//  Copyright (c) 2019 guchunhui. All rights reserved.
//

@import UIKit;
#import "TTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TTAppDelegate class]));
    }
}
