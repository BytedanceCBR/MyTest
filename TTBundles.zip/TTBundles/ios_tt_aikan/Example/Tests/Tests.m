//
//  TTAiKanTests.m
//  TTAiKanTests
//
//  Created by guchunhui on 04/16/2019.
//  Copyright (c) 2019 guchunhui. All rights reserved.
//

${TEST_EXAMPLE}
